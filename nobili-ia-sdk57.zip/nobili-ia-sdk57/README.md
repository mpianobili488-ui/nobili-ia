# Nobili IA (Expo SDK 57)

## Contenu
- App.js — interface + génération DALL·E 3 + import galerie
- package.json
- app.json

## Installation (PC)
```bash
unzip nobili-ia-sdk57.zip
cd nobili-ia-sdk57
npm install
npx expo start
```

## APK
```bash
npx eas login
npx eas build -p android --profile preview
```

## Utilisation
1. Onglet Clés → coller OPENAI_API_KEY → Enregistrer
2. Créer → prompt → Générer l'image

Ne partagez jamais votre clé API.
